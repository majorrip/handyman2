<?php
// Create connection
$con=mysqli_connect("localhost","root","","onlineauction");
echo mysqli_connect_error();
?>
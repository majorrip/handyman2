	<link rel="stylesheet" type="text/css" href="DataTables/media/css/dataTables.bootstrap.css">
	<script type="text/javascript" language="javascript" src="DataTables/media/js/jquery.dataTables.js">
	</script>
	<script type="text/javascript" language="javascript" src="DataTables/media/js/dataTables.bootstrap.js">
	</script>
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
	$('#datatable').DataTable();
} );
	</script>
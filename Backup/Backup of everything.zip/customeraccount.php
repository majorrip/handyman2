<?php
include("header.php");
?>
<!-- banner -->
	<div class="banner">
		<?php
		include("sidebar.php");
		?>
		<div class="w3l_banner_nav_right">

			<div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
				<h3 class="w3l_fruit">Customer Panel</h3>
				<div class="row">
					
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="deposit.php"><img src="images/de.jpg" alt=" " class="img-responsive" style="height: 200px;width: 300px;" /></a></center>
										</div>
										<div class="snipcart-details ">
											<center style="padding-top: 10px;"><form action="deposit.php" method="post">
												<fieldset>
													<input type="submit"  value="Deposit Amount" class="btn btn-info" />
												</fieldset>
											</form></center>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="viewmybid.php"><img src="images/view.jpg" alt=" " class="img-responsive" style="height: 200px;width: 300px;"  /></a></center>
											
											</div>
										<div class="snipcart-details border">
											<form action="viewmybid.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="View My Bid" class="btn btn-info" /></center>
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="viewwinningbid.php"><img src="images/win.jpg" alt=" " class="img-responsive"  style="height: 200px;width: 300px;" /></a></center>
											
										</div>
										<div class="snipcart-details border">
											<form action="viewwinningbid.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="Winning Bid" class="btn btn-info" /></center>
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="selectcategory.php"><img src="images/buy.jpg" alt=" " class="img-responsive" style="height: 200px;width: 300px;"  /></a></center>
											
										</div>
										<div class="snipcart-details border">
											<form action="selectcategory.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="Sell Product" class="btn btn-info" /></center>
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="viewproduct.php"><img src="images/v.jpg" alt=" " class="img-responsive"  style="height: 200px;width: 300px;" /></a></center>					
											
										</div>
										<div class="snipcart-details border">
											<form action="viewproduct.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="View Product" class="btn btn-info" /></center>
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="customerprofile.php"><img src="images/pr.png" alt=" " class="img-responsive"  style="height: 200px;width: 300px;" /></a></center>
										</div>
										<div class="snipcart-details border">
											<form action="customerprofile.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="Profile" class="btn btn-info" /></center>
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="custchangepassword.php"><img src="images/cn.jpg" alt=" " class="img-responsive"  style="height: 200px;width: 300px;" /></a></center>
										</div>
										<div class="snipcart-details border">
											<form action="custchangepassword.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="Change Password" class="btn btn-info"/></center>
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<!--- Starts here -->
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block border">
										<div class="snipcart-thumb">
											<center><a href="viewbillingcustomer.php"><img src="images/tr.png" alt=" " class="img-responsive"  style="height: 200px;width: 300px;" /></a></center>
										</div>
										<div class="snipcart-details border ">
											<form action="viewbillingcustomer.php" method="post">
												<fieldset>
													<center style="padding-top: 10px;"><input type="submit" value="View Transaction" class="btn btn-info" />
												</fieldset></center>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					<!--- Ends here -->
					
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->
<?php
include("footer.php");
?>